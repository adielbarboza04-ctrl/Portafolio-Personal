package casopractico2.adielbarboza;

public class VentasTienda {
    private int idProducto;
    private  String fechaHoraVenta;
    private double Impuestos;
    private double PrecioFinal;

    public VentasTienda() {
    }

    public VentasTienda(int idProducto, String fechaHoraVenta, double Impuestos, double PrecioFinal) {
        this.idProducto = idProducto;
        this.fechaHoraVenta = fechaHoraVenta;
        this.Impuestos = Impuestos;
        this.PrecioFinal = PrecioFinal;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getFechaHoraVenta() {
        return fechaHoraVenta;
    }

    public void setFechaHoraVenta(String fechaHoraVenta) {
        this.fechaHoraVenta = fechaHoraVenta;
    }

    public double getImpuestos() {
        return Impuestos;
    }

    public void setImpuestos(int Impuestos) {
        this.Impuestos = Impuestos;
    }

    public double getPrecioFinal() {
        return PrecioFinal;
    }

    public void setPrecioFinal(int PrecioFinal) {
        this.PrecioFinal = PrecioFinal;
    }
    
    
}
