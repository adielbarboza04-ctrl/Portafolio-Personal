package casopractico2.adielbarboza;

//los comentarios los uso aca para evitar confundirme al final cuando revise el codigo
//\n salto de pagina para copiar y pegar

import javax.swing.JOptionPane;

public class CasoPractico2AdielBarboza {

    public static void main(String[] args) {
        String menuOpciones = ""; // esto se utiliza para evitar errores
        VentasTienda[] arregloVentas = new VentasTienda[10]; //valor necesario pero sin embargo puede ser mayor
        int contadorVentas = 0;
        
        do {
           menuOpciones = JOptionPane.showInputDialog("Menu \n" 
                   + "1. Registrar nueva venta\n" 
                   + "2. Ver total de ventas hasta el momento ordenadas de mayor a menor\n" 
                   + "3. Hacer cierre del día\n" 
                   + "Ingrese el numero al menu segundario que quiera entrar");
           
           switch (menuOpciones) {
               case "1":
                   JOptionPane.showMessageDialog(null, "Menu Registrar nueva venta");
                   
                   break;
                   
               case "2":
                   JOptionPane.showMessageDialog(null, "Menu Ver total de ventas hasta el momento ordenadas de mayor a menor");
                   break;
                   
               case "3":
                   JOptionPane.showMessageDialog(null, "Menu Hacer cierre del día");
                   break;
               
               default:
                   JOptionPane.showMessageDialog(null, "Haz ingresado una opcion incorrecta.");
           }
        } while (!menuOpciones.equals("3"));
    }        
        public static int menuRegistroNuevaVenta(VentasTienda[] arregloVentas, int contadorVentas) {
            
           int idProductoIngresado = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id del prodructo"));
           String fechaHoraVentaIngresada = JOptionPane.showInputDialog("Ingrese la hora de la venta");
           double precioIngresado = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el Precio de la venta"));
           
           if (precioIngresado <= 0){
               JOptionPane.showMessageDialog(null, "Usted ha ingresado un dato incorrecto, el dato debe ser mayor a 0.");
               return contadorVentas; //esto sirve para que se calncele el registro
           }
           double impuesto = precioIngresado * 0.13;
           double precioFinal = precioIngresado + impuesto;
           
           VentasTienda nuevaVenta = new VentasTienda(idProductoIngresado, fechaHoraVentaIngresada, impuesto, precioFinal);
           arregloVentas[contadorVentas] = nuevaVenta;
           
           return contadorVentas + 1;
        }
       public static void totalVentas(VentasTienda[] arregloVentas, int contadorVentas){
           
       } 
    }

        
    

