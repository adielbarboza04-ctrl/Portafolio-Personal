
package proyectoFinal;

public class Vehiculo {
         
    private String placa;
    private String modelo;
    private int anio;
    private String propietario;
 
    public Vehiculo(String placa, String modelo, int anio, String propietario) {
        this.placa = placa;
        this.modelo = modelo;
        this.anio = anio;
        this.propietario = propietario;
    }
 
    public String getPlaca() {
        return placa;
    }
 
    public String getModelo() {
        return modelo;
    }
 
    public int getAnio() {
        return anio;
    }
 
    public String getPropietario() {
        return propietario;
    }
 
    public void setPlaca(String placa) {
        this.placa = placa;
    }
 
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
 
    public void setAnio(int anio) {
        this.anio = anio;
    }
 
    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }
}   

