
package proyectoFinal;

import javax.swing.JOptionPane;

public class OrdenTrabajo {
       private Vehiculo Vehiculo;
    private String placaVehiculo;
    private String tipoServicio;
    private String nombreMecanico;
    private String estado;
    private String fechaModificacion;

    public Vehiculo getVehiculo() {
        return Vehiculo;
    }

    public void setVehiculo(Vehiculo Vehiculo) {
        this.Vehiculo = Vehiculo;
    }

    public String getPlacaVehiculo() {
        return placaVehiculo;
    }

    public void setPlacaVehiculo(String placaVehiculo) {
        this.placaVehiculo = placaVehiculo;
    }

    public String getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    public String getNombreMecanico() {
        return nombreMecanico;
    }

    public void setNombreMecanico(String nombreMecanico) {
        this.nombreMecanico = nombreMecanico;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(String fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }
    
    
    public OrdenTrabajo asignarOrden(String placa, String tipoServicio,
            String nombreMecanico, String estado, String fecha) {

        if (placa.equals("") || tipoServicio.equals("")
                || nombreMecanico.equals("") || estado.equals("")) {

            JOptionPane.showMessageDialog(null, "Todos los datos son obligatorios.");

            return null;
        }

        if (!tipoServicio.equalsIgnoreCase("Diagnostico") && !tipoServicio.equalsIgnoreCase("Corregido")
                && !tipoServicio.equalsIgnoreCase("Mantenimiento Preventivo")) {

            JOptionPane.showMessageDialog(null,"Tipo de servicio incorrecto.");

            return null;
        }

        OrdenTrabajo nuevaOrden = new OrdenTrabajo();

        nuevaOrden.setPlacaVehiculo(placa);
        nuevaOrden.setTipoServicio(tipoServicio);
        nuevaOrden.setNombreMecanico(nombreMecanico);
        nuevaOrden.setEstado(estado);
        nuevaOrden.setFechaModificacion(fecha);

        JOptionPane.showMessageDialog(null,"Su orden a sido creada correctamente.");

        return nuevaOrden;
    }

    
    public boolean validarEstadoOrden(String estadoAnterior, String nuevoEstado) {

        if (estadoAnterior.equalsIgnoreCase("Cancelada")) { 
            JOptionPane.showMessageDialog(null, "La orden está cancelada.");

            return false;
        }

        if (estadoAnterior.equalsIgnoreCase("Completada")) {

            JOptionPane.showMessageDialog(null, "La orden ya está completada.");

            return false;
        }

        if (estadoAnterior.equalsIgnoreCase("Pendiente") && nuevoEstado.equalsIgnoreCase("Completada")) {

            JOptionPane.showMessageDialog(null, "Disculpe, su solicitud, No puede pasar de Pendiente a Completada.");

            return false;
        }

        return true;
    }

   
    public void asignarMecanico(String mecanico) {

        if (mecanico.equals("")) {

            JOptionPane.showMessageDialog(null, "Debe ingresar un mecánico.");

            return;
        }

        this.nombreMecanico = mecanico;

        JOptionPane.showMessageDialog(null, "El Mecánico se ha asignado correctamente.");
    }

}
  