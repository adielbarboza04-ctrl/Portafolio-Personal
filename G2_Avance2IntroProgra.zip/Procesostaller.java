package proyectoFinal;

import javax.swing.JOptionPane;

public class Procesostaller {

    
    public static Vehiculo[] registrarVehiculo(String placa, String modelo,
            int anio, String propietario, Vehiculo[] vehiculos,
            OrdenTrabajo[] ordenes) {

        if (placa.equals("") || modelo.equals("") || propietario.equals("")) {
            JOptionPane.showMessageDialog(null, "Debe completar todos los datos.");
            return vehiculos;
        }

        if (existeVehiculo(placa, ordenes)) {
            JOptionPane.showMessageDialog(null, "El vehículo ya tiene una orden activa.");
            return vehiculos;
        }

        for (int i = 0; i < vehiculos.length; i++) {

            if (vehiculos[i] == null) {

                vehiculos[i] = new Vehiculo(placa, modelo, anio, propietario);

                JOptionPane.showMessageDialog(null, "Vehículo registrado correctamente.");

                return vehiculos;
            }

        }

        JOptionPane.showMessageDialog(null, "No hay espacio para registrar más vehículos.");

        return vehiculos;
    }

   
    public static boolean validarDisponibilidadMecanico(String mecanico, OrdenTrabajo[] ordenes) {

        int cantidad = 0;

        for (int i = 0; i < ordenes.length; i++) {

            if (ordenes[i] != null) {

                if (ordenes[i].getNombreMecanico().equalsIgnoreCase(mecanico)
                        && !ordenes[i].getEstado().equalsIgnoreCase("Completada")
                        && !ordenes[i].getEstado().equalsIgnoreCase("Cancelada")) {

                    cantidad++;

                }

            }

        }

        return cantidad < 3;
    }

   
    public static String[] obtenerVehiculosPorMecanico(String mecanico, OrdenTrabajo[] ordenes) {

        String[] placas = new String[ordenes.length];
        int posicion = 0;

        for (int i = 0; i < ordenes.length; i++) {

            if (ordenes[i] != null) {

                if (ordenes[i].getNombreMecanico().equalsIgnoreCase(mecanico)) {

                    placas[posicion] = ordenes[i].getPlacaVehiculo();
                    posicion++;

                }

            }

        }

        return placas;
    }


    public static OrdenTrabajo[] buscarOrdenesPorEstado(OrdenTrabajo[] ordenes, String estado, String fechaModificacion) {
    OrdenTrabajo[] resultados = new OrdenTrabajo[ordenes.length];
        int posicion = 0;
        for(int i = 0; i < ordenes.length; i++) {
            if (ordenes[i] != null) {
                if (ordenes[i].getEstado().equalsIgnoreCase(estado)) {
                    if(fechaModificacion == null || ordenes[i].getFechaModificacion().equalsIgnoreCase(fechaModificacion)){
                    resultados[posicion] = ordenes[i];
                    posicion++;
                    }
                }     
            }
        }
        return resultados;
    }
    
    public static boolean existeVehiculo(String placa, OrdenTrabajo[] ordenes) {

    for (int i = 0; i < ordenes.length; i++) {

        if (ordenes[i] != null) {

            if (ordenes[i].getPlacaVehiculo().equalsIgnoreCase(placa)
                    && !ordenes[i].getEstado().equalsIgnoreCase("Completada")
                    && !ordenes[i].getEstado().equalsIgnoreCase("Cancelada")) {

                return true;

            }

        }

    }

    return false;
}
    public static boolean asignarMecanico(OrdenTrabajo orden, String mecanico, OrdenTrabajo[] ordenes) {

    if (!validarDisponibilidadMecanico(mecanico, ordenes)) {

        JOptionPane.showMessageDialog(null,
                "El mecánico no está disponible.");

        return false;
    }

    if (!orden.validarEstadoOrden(orden.getEstado(), "En Proceso")) {

        JOptionPane.showMessageDialog(null,
                "No se puede asignar el mecánico.");

        return false;
    }

    orden.setNombreMecanico(mecanico);

    return true;
}
    
    public static String reporteTrabajoDiario(OrdenTrabajo[] ordenes, String estado, String fecha) {

    OrdenTrabajo[] reporte = buscarOrdenesPorEstado(ordenes, estado, fecha);

    String mensaje = "";

    for (int i = 0; i < reporte.length; i++) {

        if (reporte[i] != null) {

            mensaje += "Placa: "
                    + reporte[i].getPlacaVehiculo() 
                    + "\n";

            mensaje += "Servicio: "
                    + reporte[i].getTipoServicio()
                    + "\n";

            mensaje += "Estado: "
                    + reporte[i].getEstado()
                    + "\n\n";

        }

    }

    return mensaje;
}

public static String generarReporteServicios(OrdenTrabajo[] ordenes) {

    if (ordenes == null || ordenes.length == 0) {
        JOptionPane.showMessageDialog(null, "No existen órdenes de trabajo.");
        return "";
    }

    int totalPreventivo = 0;
    int totalCorrectivo = 0;
    int totalDiagnostico = 0;

    String reporte = "";

    for (int i = 0; i < ordenes.length; i++) {

        if (ordenes[i] != null) {

            reporte += "Placa: " + ordenes[i].getPlacaVehiculo() + "\n";
            reporte += "Servicio: " + ordenes[i].getTipoServicio() + "\n";
            reporte += "Mecánico: " + ordenes[i].getNombreMecanico() + "\n";
            reporte += "Estado: " + ordenes[i].getEstado() + "\n\n";

            if (ordenes[i].getTipoServicio().equalsIgnoreCase("Mantenimiento Preventivo")) {
                totalPreventivo++;
            }

            if (ordenes[i].getTipoServicio().equalsIgnoreCase("Correctivo")) {
                totalCorrectivo++;
            }

            if (ordenes[i].getTipoServicio().equalsIgnoreCase("Diagnostico")) {
                totalDiagnostico++;
            }
        }
    }

    reporte += "Total Preventivos: " + totalPreventivo + "\n";
    reporte += "Total Correctivos: " + totalCorrectivo + "\n";
    reporte += "Total Diagnósticos: " + totalDiagnostico;

    return reporte;
}
    
    
}