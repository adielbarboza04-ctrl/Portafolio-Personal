package proyectoFinal;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {

        Vehiculo vehiculo1 = new Vehiculo("ABC-123", "Toyota Yaris", 2015, "Juan Martínez");
        Vehiculo vehiculo2 = new Vehiculo("XYZ-987", "Honda Civic", 2020, "María Gómez");

        
        OrdenTrabajo orden1 = new OrdenTrabajo();
        OrdenTrabajo orden2 = new OrdenTrabajo();

        orden1.setVehiculo(vehiculo1);
        orden1.setPlacaVehiculo(vehiculo1.getPlaca());
        orden1.setTipoServicio("Diagnostico");
        orden1.setNombreMecanico("Mario Jiménez");
        orden1.setEstado("Pendiente");
        orden1.setFechaModificacion("18/07/2026");

        orden2.setVehiculo(vehiculo2);
        orden2.setPlacaVehiculo(vehiculo2.getPlaca());
        orden2.setTipoServicio("Correctivo");
        orden2.setNombreMecanico("Raúl Porras");
        orden2.setEstado("En Proceso");
        orden2.setFechaModificacion("18/07/2026");

        Vehiculo[] inventarioVehiculos = new Vehiculo[5];
        OrdenTrabajo[] registroOrdenes = new OrdenTrabajo[5];

        inventarioVehiculos[0] = vehiculo1;
        inventarioVehiculos[1] = vehiculo2;

        registroOrdenes[0] = orden1;
        registroOrdenes[1] = orden2;

        JOptionPane.showMessageDialog(null, "Sistema de Taller Mecánico ZA-MA-BAR");

      
        String placa = JOptionPane.showInputDialog("Ingrese la placa:");

        // USAMOS TRIM sirve para eliminar los espacios en blanco al inicio 
        //y al final de un texto. Lo utilicé para que, si el usuario escribe solo espacios
        //en lugar de un dato, el sistema lo detecte como un campo vacío y muestre un mensaje de error." 
        
        if (placa == null || placa.trim().equals("")) {
        JOptionPane.showMessageDialog(null, "Error: Debe ingresar una placa.");
        return;
}
        //modelo del carro que se ingreso al taller
        String modelo = JOptionPane.showInputDialog("Ingrese el modelo:");

        if (modelo == null || modelo.trim().equals("")) {    
        JOptionPane.showMessageDialog(null, "Error: Debe ingresar el modelo.");
        
        return;
}
        //anio del carro ingresado 
        int anio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el año:"));

        
        //PROPIETARIO DEL CARRO
        String propietario = JOptionPane.showInputDialog("Ingrese el propietario:");

        if (propietario == null || propietario.trim().equals("")) {
        JOptionPane.showMessageDialog(null, "Error: Debe ingresar el propietario.");
        
        return;
}
        Procesostaller.registrarVehiculo(placa, modelo, anio, propietario, inventarioVehiculos, registroOrdenes);

        
        String mecanico = JOptionPane.showInputDialog("Ingrese el nombre del mecánico:");
        
        if (mecanico == null || mecanico.trim().equals("")) {
        JOptionPane.showMessageDialog(null, "Error: Debe ingresar el nombre del mecánico.");
        
        return;
}

        boolean disponible = Procesostaller.validarDisponibilidadMecanico(mecanico, registroOrdenes);

        JOptionPane.showMessageDialog(null, "¿" + mecanico + " está disponible?\n" + disponible);;

       
        String placaBuscar = JOptionPane.showInputDialog( "Ingrese la placa a buscar:");
        
        if (placaBuscar == null || placaBuscar.trim().equals("")) {
        JOptionPane.showMessageDialog(null, "Error: Debe ingresar una placa.");
        
        return;
}

        boolean existe = Procesostaller.existeVehiculo( placaBuscar, registroOrdenes);

        JOptionPane.showMessageDialog(null, "¿El vehículo " + placaBuscar + " tiene una orden activa?\n" + existe);

        
        String estado = JOptionPane.showInputDialog( "Ingrese el estado:\n"
                + "Pendiente\n"
                + "En Proceso\n"
                + "Completada\n"
                + "Cancelada");

        if (!estado.equalsIgnoreCase("Pendiente")
        && !estado.equalsIgnoreCase("En Proceso")
        && !estado.equalsIgnoreCase("Completada")
        && !estado.equalsIgnoreCase("Cancelada")) {

        JOptionPane.showMessageDialog(null, "Error: Estado no válido.");
        
        return;
}

        String fecha = JOptionPane.showInputDialog( "Ingrese la fecha (opcional):");

        OrdenTrabajo[] pendientes = Procesostaller.buscarOrdenesPorEstado(registroOrdenes, estado,fecha);

        if (pendientes[0] != null) {

        JOptionPane.showMessageDialog(null, "Primera orden encontrada:\n" + pendientes[0].getPlacaVehiculo());

        } else {

        JOptionPane.showMessageDialog(null, "No se encontraron órdenes.");

}
        
        String servicio = JOptionPane.showInputDialog( "Ingrese el tipo de servicio:");

        if (!servicio.equalsIgnoreCase("Diagnostico")
        && !servicio.equalsIgnoreCase("Correctivo")
        && !servicio.equalsIgnoreCase("Mantenimiento Preventivo")) {

        JOptionPane.showMessageDialog(null, "Error: Tipo de servicio incorrecto.");
        
        return;
}

       
        String mecanicoBuscar = JOptionPane.showInputDialog( "Ingrese el nombre del mecánico:");

        String[] placas = Procesostaller.obtenerVehiculosPorMecanico( mecanicoBuscar, registroOrdenes);

        JOptionPane.showMessageDialog(null, "Primer vehículo asignado a " + mecanicoBuscar + ":\n" + placas[0]);

      
        String estadoReporte = JOptionPane.showInputDialog("Estado:");

        String fechaReporte = JOptionPane.showInputDialog( "Fecha:");
        
        if (fechaReporte == null || fechaReporte.trim().equals("")) {
        JOptionPane.showMessageDialog(null, "Error: Debe ingresar la fecha.");
    
        return;
}

        String reporte = Procesostaller.reporteTrabajoDiario( registroOrdenes, estadoReporte,fechaReporte);

        JOptionPane.showMessageDialog(null, reporte);

    
        JOptionPane.showMessageDialog(null, Procesostaller.generarReporteServicios(registroOrdenes));

    }
}