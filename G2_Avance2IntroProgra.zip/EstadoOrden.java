
package proyectoFinal;

public enum EstadoOrden {
    
    PENDIENTE,
    EN_PROCESO,
    COMPLETADA,
    CANCELADA
    
}
