package casoestudio;


public class Aeronave {
    private String id;
    private String modelo;
    private int captotalPasajeros;
    private piloto pilotoPrincipal;
    
    public Aeronave(){
        
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCaptotalPasajeros() {
        return captotalPasajeros;
    }

    public void setCaptotalPasajeros(int captotalPasajeros) {
        this.captotalPasajeros = captotalPasajeros;
    }

    public piloto getPilotoPrincipal() {
        return pilotoPrincipal;
    }

    public void setPilotoPrincipal(piloto pilotoPrincipal) {
        this.pilotoPrincipal = pilotoPrincipal;
    }
    
    public void asignarPiloto(piloto nuevoPiloto){
        this.pilotoPrincipal = nuevoPiloto;
        
    }
}
