package casoestudio;

public class Vuelo {
    private String numeroVuelo;
    private String aerolina;
    private String destino;
    private String horaSalida;
    private String estado;
    private Aeronave aeronaveAsociada;

    public String getNumeroVuelos() {
        return numeroVuelo;
    }

    public void setNumeroVuelos(String numeroVuelos) {
        this.numeroVuelo = numeroVuelos;
    }

    public String getAerolina() {
        return aerolina;
    }

    public void setAerolina(String aerolina) {
        this.aerolina = aerolina;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(String horaSalida) {
        this.horaSalida = horaSalida;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String nuevoEstado) {
        if (nuevoEstado.equalsIgnoreCase("Programado") || nuevoEstado.equalsIgnoreCase("Abordando") || 
        nuevoEstado.equalsIgnoreCase("En vuelo") || nuevoEstado.equalsIgnoreCase("Aterrizado") || 
        nuevoEstado.equalsIgnoreCase("Cancelado"))
        this.estado = nuevoEstado;
    }

    public Aeronave getAeronaveAsociada() {
        return aeronaveAsociada;
    }

    public void setAeronaveAsociada(Aeronave nuevaAeronave) {
        this.aeronaveAsociada = nuevaAeronave;
    }
    public boolean verificarCapacidad(int pasajerosInscritos) {
    if (pasajerosInscritos <= this.aeronaveAsociada.getCaptotalPasajeros()) {
        return true;
    } else {
        return false;
        }
    }
}
