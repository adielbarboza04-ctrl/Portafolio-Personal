package casoestudio;

import javax.swing.JOptionPane;


public class CasoEstudio {

   
    public static void main(String[] args) {
        
     //Todo lo de la clase piloto aca 
     piloto p1 = new piloto();
        p1.setId("P001");
        p1.setNombre("Juan Perez");
        p1.setLicencia("LIC123");

        piloto p2 = new piloto();
        p2.setId("P002");
        p2.setNombre("Ana Lopez");
        p2.setLicencia("LIC456");
        
        //Todo lo de la clase aeronave va aca
        Aeronave a1 = new Aeronave();
        a1.setId("0912");
        a1.setModelo("boing65");
        a1.setCaptotalPasajeros(120);
        
        Aeronave a2 = new Aeronave();
        a2.setId("1240");
        a2.setModelo("boing100");
        a2.setCaptotalPasajeros(150);
        
        a1.asignarPiloto(p1);
        a2.asignarPiloto(p2);
        
        //Aca va todo lo de vuelo
        Vuelo v1 = new Vuelo();
        v1.setNumeroVuelos("A123");
        v1.setAerolina("Emirates");
        v1.setDestino("Madrid");
        v1.setHoraSalida("23:00");
        v1.setEstado("Programado");
        v1.setAeronaveAsociada(a1);
        
        Vuelo v2 = new Vuelo();
        v2.setNumeroVuelos("B123");
        v2.setAerolina("Emirates");
        v2.setDestino("San Jose/ Costa Rica");
        v2.setHoraSalida("10:00");
        v2.setEstado("Abordando");
        v2.setAeronaveAsociada(a2);
        
        //Profe la verdad es que hasta pude llegar, estoy que se me caen los ojos del sueño, le entregue este documento 
        //pero igualmente voy a tratar de terminarlo yo mismo ya sin presion y sin sueño
        
    }
    
}
